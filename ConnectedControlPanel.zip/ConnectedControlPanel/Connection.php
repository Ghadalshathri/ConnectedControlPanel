<?php
$user = 'root';
$password = 'root';
$db = 'Robot';
$host = 'localhost';
$con= mysqli_connect($host,$user,$password,$db);



?>
