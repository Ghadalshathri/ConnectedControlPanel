  <!DOCTYPE html>
<html>

<head>
    <title>Control Panel</title>
    <link rel="icon" href="img/remote-control.png">
</head>

<style>
html{
background-image:url('background.jpg');
 background-repeat: no-repeat;
 background-size: cover;
}

@import "compass/css3";

$bg: #60B8CE;
$shadow: rgba(0,0,0,0.4);
$button-in: #fff;
$button-out: #eee;

body{
  background: grey;
}

nav{
  width:400px;
  height:400px;
  background:  #666666;
  border-radius: 50%;
  padding: 20px;
  -webkit-transform: rotate(45deg);
  -moz-transform: rotate(45deg);
  transform: rotate(45deg);
  box-shadow: inset -12px 0 12px -6px #ddd,
    inset 12px 0 12px -6px #FFF,
    inset 0 0 0 12px #EEE,
    inset 2px 0 4px 12px $shadow,
    1px 0 4px rgba(0,0,0,0.8);
  box-sizing: border-box;
  position: relative;
  margin: 10px auto;
}

a {
  text-decoration: none;

}

.center-button{
  display: block;
  height: 38%;
  width: 38%;
  position: absolute;
  top: 31%;
  left: 31%;
  background:
linear-gradient(to right, rgba(204,17,0,1) 0%, rgba(204,17,0,1) 100%);
  border-radius: 50%;
  box-shadow: 1px 0 4px rgba(0,0,0,0.8);
}

.button{
  display: block;
  width: 46%;
  height: 46%;
  margin: 2%;
  position: relative;
  float: left;
  box-shadow: 1px 0px 3px 1px $shadow, inset 0 0 0 1px #FFF;
}

.button::after{
  content: "";
  display: block;
  width: 50%;
  height: 50%;
  background: white;
  position: absolute;
  border-radius: inherit;
}

.button.top{
  border-radius: 100% 0 0 0;
  background:
  #ffde59;
}
.button.top::after{
  bottom: 0;
  right: 0;
  box-shadow: inset 2px 1px 2px 0 $shadow, 10px 10px 0 10px $bg;
  -webkit-transform: skew(-3deg,-3deg) scale(0.96);
  -moz-transform: skew(-3deg,-3deg) scale(0.96);
  transform: skew(-3deg,-3deg) scale(0.96);
}

.button.right{
  border-radius: 0 100% 0 0;
  background:
linear-gradient(to right, rgba(248,250,235,1) 0%, rgba(232,239,209,1) 0%, rgba(232,234,190,1) 100%);}
.button.right::after{
  bottom: 0;
  left: 0;
  box-shadow: inset -2px 3px 2px -2px $shadow, -10px 10px 0 10px $bg;
  -webkit-transform: skew(3deg,3deg) scale(0.96);
  -moz-transform: skew(3deg,3deg) scale(0.96);
  transform: skew(3deg,3deg) scale(0.96);
}

.button.left{
  border-radius: 0 0 0 100%;

background:
linear-gradient(45deg, rgba(255,248,168,1) 0%, rgba(255,248,168,1) 98%, rgba(254,239,138,1) 100%);}

.button.left::after{
  top: 0;
  right: 0;
  box-shadow: inset 2px -1px 2px 0 $shadow, 10px -10px 0 10px $bg;
  -webkit-transform: skew(3deg,3deg) scale(0.96);
  -moz-transform: skew(3deg,3deg) scale(0.96);
  transform: skew(3deg,3deg) scale(0.96);
}

.button.bottom{
  border-radius: 0 0 100% 0;
  background:
linear-gradient(45deg, rgba(255,255,255,1) 0%, rgba(255,255,255,1) 0%, rgba(176,200,157,1) 2%);}
.button.bottom::after{
  top: 0;
  left: 0;
  box-shadow: inset -2px -3px 2px -2px $shadow, -10px -10px 0 10px $bg;
  -webkit-transform: skew(-3deg,-3deg) scale(0.96);
  -moz-transform: skew(-3deg,-3deg) scale(0.96);
  transform: skew(-3deg,-3deg) scale(0.96);
}

i {
  -webkit-transform:
    rotate(-45deg);
  -moz-transform: rotate(-45deg);
  transform: rotate(-45deg);
  position: absolute;
  font-size: 42px;
  top: 19%;
  left: 15%;
  right: 1%;
  bottom: 90%
  text-shadow: 1px 1px 4px #FFF, 0px 0px 0px rgba(0,0,0,0.5);
  color: black;


}

.top i {
  top:30%;
  left:0%;
  right: 0%;
  bottom: 50%;
}

.left i {
  right: 25%;
  bottom: 39%;
    transform:rotate(-140deg);

}

.right i {
  top:39%;
  left:19%;
  transform:rotate(45deg);
}

.bottom i {
  top:30%;
  left:1%;
  right: 1%;
}


h1{
  color: black;
}
  </style>
<body>





<h1 align="center">Control Panel</h1>

<br><br><br><br><br>

<nav>
   <a class="button top" name="forward" href="view.php?way=forward&dir_color=rgba(255, 222, 89, 1)"><i class="icon-play">Forward</i></a>
  <a class="button right" name="right" href="view.php?way=right&dir_color=rgba(232,234,190,1)"><i class="icon-forward">Right</i></a>
  <a class="button left" name="left" href="view.php?way=left&dir_color=rgba(254,239,138,1)"><i class="icon-backward">Left</i></a>
  <a class="button bottom" name="background" href="view.php?way=backward&dir_color=rgba(176,200,157,1)"><i class="icon-pause">Backward</i></a>
  <a class="center-button" name="stop" href="view.php?way=stop&dir_color=rgba(204,17,0,1);"><i class="icon-stop">Stop</i></a>
</nav>

</body>
</html>
