<?php
$direction='none';
if(isset($_GET["way"]))
{
  $direction=$_GET["way"];
}
if ($direction=='none'||$_GET["dir_color"]=='') {
  header('location: ./panel.php');
}



?><!DOCTYPE html>
<html>

<head>
  <link rel="stylesheet" href="css/bootstrap.min.css">

    <link rel="icon" href="img/remote-control.png">
        <title>Control Panel</title>
</head>


<body>
<style>
body{
  background-image: url("img/background.jpg");
  background-size: 150%;
  background-repeat: repeat-y;
}
  #control {
    size: 10vh;
    position:absolute;


    bottom:0px;
    right:40%;
    left:50%;
    
    margin-left:-150px;
}
.head{
        background: <?php echo ($_GET["dir_color"])?>;
        border-radius: 50%;
        width: 100px;
        height: 100px;
        position: absolute;

        color:black;
        text-align: center;
        font-weight: bolder;
        margin-left:37%;
        padding:50px;
        height: 300px;
        width: 300px;
}
</style>





<h1 class=" text-center text-info">Control Panel</h1>
<br><br><br><br><br><br><br>  
<?php
if ($direction=='none'||$_GET["dir_color"]=='') {
  header('location: index.php');
}
include('Connection.php');




if ($direction=='forward'||$direction=='backward'||$direction=='left'||$direction=='right'||$direction=='stop') {
 $sql="UPDATE `control panel` SET `ID`=1,`Direction`='$direction' WHERE 1";
 $query = mysqli_query($con,$sql);
 if ($query) {
 
   ?><div class="head"><h1 class="text-center"><?php echo($direction)?></h1></div>
   <?php
 }
}
elseif ($direction=='none'||$_GET["dir_color"]=='') {
  header('location: ./panel.php');
}


?>

</body>
</html>
